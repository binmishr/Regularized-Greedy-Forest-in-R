library(testthat)
library(RGF)

test_check("RGF")
